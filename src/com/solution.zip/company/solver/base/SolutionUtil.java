package com.company.solver.base;

public class SolutionUtil {

    private SolutionUtil(){}

    public static <T> SolutionSnapshot<T> trySolutions(Solver<T> solver, Solution<T> solution, int times) {
        var bestSolution = solution.getSolutionSnapshot();
        for (int i = 0; i < times; i++) {
            var currentSolution = solver.solve(solution);
            if (currentSolution.getScore() > bestSolution.getScore()) {
                bestSolution = currentSolution;
            }
        }
        return bestSolution;
    }

}
