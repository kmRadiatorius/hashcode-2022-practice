package com.company;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Client {

    public final Set<String> likes;
    public final Set<String> dislikes;

    public Client(List<String> likes, List<String> dislikes) {
        this.likes = likes.stream().collect(Collectors.toSet());
        this.dislikes = dislikes.stream().collect(Collectors.toSet());
    }

    public boolean likesPizza(Set<String> ingredients) {
        return likes.stream().allMatch(ingredients::contains) && dislikes.stream().noneMatch(ingredients::contains);
    }
}
