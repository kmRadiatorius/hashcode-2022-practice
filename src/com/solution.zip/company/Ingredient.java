package com.company;

public class Ingredient {

    public String name;
    public boolean selected;
}
