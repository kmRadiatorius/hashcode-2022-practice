package com.company;

import java.util.List;
import java.util.stream.Collectors;

public class Scorer {

    public static int score(List<String> ingredients, List<Client> clients) {
        int score = 0;
        var ingrSet = ingredients.stream().collect(Collectors.toSet());
        for (var client: clients) {
            if (client.likes.stream().allMatch(ingrSet::contains)
            && client.dislikes.stream().noneMatch(ingrSet::contains)) {
                score++;
            }
        }

        return score;
    }
}
