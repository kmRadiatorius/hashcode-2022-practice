package com.company;

import java.util.Set;

public class SimulatedAnnealing {

    public int initialTemperature;
    public int maxIterations;
    public double coolingRate;

    public SimulatedAnnealing(int initialTemperature, int maxIterations, double coolingRate) {
        this.initialTemperature = initialTemperature;
        this.maxIterations = maxIterations;
        this.coolingRate = coolingRate;
    }

    public Set<String> solve(Data solution) {
        double t = initialTemperature;
        Set<String> bestSolution = solution.getSolution();
        double bestScore = solution.getScore(bestSolution);

        for (int i = 0; i < maxIterations; i++) {
            if (t > 0.1) {
                solution.doChange();
                Set<String> currentSolution = solution.getSolution();
                double currentScore = solution.getScore(currentSolution);

                if (currentScore > bestScore) {
                    bestScore = currentScore;
                    bestSolution = currentSolution;
                } else if (Math.exp(bestScore - currentScore) / t < Math.random()) {
                    solution.revertChange();
                }
            }
            t *= coolingRate;
        }

        return bestSolution;
    }

}
