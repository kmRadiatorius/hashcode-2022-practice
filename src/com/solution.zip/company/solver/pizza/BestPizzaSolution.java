package com.company.solver.pizza;

import com.company.Client;
import com.company.solver.base.Solution;
import com.company.solver.base.SolutionSnapshot;

import java.util.*;
import java.util.stream.Collectors;

public class BestPizzaSolution implements Solution<Set<String>> {

    private static final Random rand = new Random();

    private List<String> ingredients;
    private List<Client> clients;
    private List<Boolean> selection;
    private List<Boolean> previousSelection;

    public BestPizzaSolution(List<Client> clients) {
        this.clients = clients;
        ingredients = extractIngredients(clients);
        selection = randomizeSelection(ingredients.size());
    }

    public void doChange() {
        int a = nextIndex();
        previousSelection = new ArrayList<>(selection);
        selection.set(a, !selection.get(a));
    }

    public void revertChange() {
        selection = previousSelection;
    }

    @Override
    public BestPizza getSolutionSnapshot() {
        var selected = new HashSet<String>();
        for (int i = 0; i < ingredients.size(); i++) {
            if (selection.get(i)){
                selected.add(ingredients.get(i));
            }
        }

        return new BestPizza(selected, getScore(selected));
    }

    public BestPizzaSolution copy() {
        return new BestPizzaSolution(clients);
    }

    private double getScore(Set<String> solution) {
        return clients.stream()
                .filter(client -> client.likesPizza(solution))
                .count();
    }

    private int nextIndex() {
        return Math.abs(rand.nextInt()) % ingredients.size();
    }

    private List<String> extractIngredients(List<Client> clients) {
        var allIngredients = clients.stream()
                .flatMap(a -> a.likes.stream())
                .collect(Collectors.toList());

        allIngredients.addAll(clients.stream()
                .flatMap(a -> a.dislikes.stream())
                .collect(Collectors.toList()));

        return allIngredients;
    }

    private List<Boolean> randomizeSelection(int count) {
        var selection = new ArrayList<Boolean>();
        for (int i = 0; i < count; i++) {
            selection.add(rand.nextBoolean());
        }

        return selection;
    }
}
